const express = require('express');
const axios = require('axios');

const app = express()
const PORT = 3000;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));

app.get('/', async (req, res) => {
    const type = req.query.avatarStyle;
    if(type){
    try {
        const apiUrl = `https://api.dicebear.com/9.x/${type}/svg`;
        res.render('index.ejs', { data: apiUrl });
    }
    catch (e) {
        console.log("Error: " + e);
    }
    }
    else{
        res.render('index.ejs',{error: "Please Select your Avatar type"})
    }
})


app.listen(PORT,()=>{
    console.log(`Your app is running on port ${PORT}`)
})